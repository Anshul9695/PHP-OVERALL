<div class="container">
      <h1><?php echo $arr['title']?></h1>
	  <div>
		<?php echo $arr['data']?>
	  </div>
    </div>