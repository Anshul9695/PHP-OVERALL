<?php
$arr=array('Noida','Delhi','Pune');
?>